<?php
    $db_server = "server303.web-hosting.com";
    $db_user = "techtwvo_tech_121_techowl_gee2020";
    $db_pass = "NORTHERNER_tony_2020";
    $con = mysqli_connect($db_server, $db_user, $db_pass); 
    if(!$con) {
        die("Connection failed " . mysqli_connect_error());
        exit();
    }
?>