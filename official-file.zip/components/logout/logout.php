<?php
    session_start();

    if(!isset($_SESSION['IS_LOGOUT']) || $_SESSION['IS_LOGOUT'] !== "kfdj783ai49GHaE4N5dlgw") {
        header("Location: ../../../pricing.php");
        exit();
    } else {
        session_destroy();
        echo "<script>sessionStorage.clear()</script>";
        header("Location: ../../../pricing.php");
        exit();
    };
?>