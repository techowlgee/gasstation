<?php  
        if($_SERVER["REQUEST_METHOD"] == "POST") {
            function testData($data) {
                $data = trim($data);
                $data = stripslashes($data);
                $data = htmlspecialchars($data);
                return $data;
            }
            $post_name = $_POST["fullname"];
            $post_email = $_POST["email"];
            $post_subject = $_POST["subject"];
            $post_message = $_POST["message"];
            //Verify recaptcha
            $recaptcha = $_POST['g-recaptcha-response'];
            $secret_key = '6LdcaKYnAAAAABOWqZSKVsJc6HI6RWLTswUP_N55';
            $url = 'https://www.google.com/recaptcha/api/siteverify?secret=' . $secret_key . '&response='. $recaptcha . '&remoteip=' . $_SERVER['REMOTE_ADDR'];
            $response = file_get_contents($url);
            $response = json_decode($response);
            if($response->success == true) {
                if(empty($post_name) || empty($post_email) || empty($post_subject) || empty($post_message)) {
                    echo "Sorry, all input fileds required!";
                } else {
                    $name = testData($post_name);
                    $email = testData($post_email);
                    $subject = testData($post_subject);
                    $message = testData($post_message);
                    /*
                    WRITE DAT TO JSON FILE ON SERVER
                    SOURCE CODE = https://www.nidup.io/blog/manipulate-json-files-in-php
                    */
                    $path = "../../json/contacts.json";
                    $getPathContent = file_get_contents($path);
                    $decodeToArray = json_decode($getPathContent, true);

                    $decodeToArray[] = [
                        "name" => $name,
                        "email" => $email,
                        "subject" => $subject,
                        "message" => $message
                    ];
                    $appendToJason = json_encode($decodeToArray, JSON_PRETTY_PRINT);
                    $fileOpen = fopen($path, "w");
                    fwrite($fileOpen, $appendToJason);
                    fclose($fileOpen);  
                    echo "Thanks for reaching out to us. \n \n Your message has been recieved and we will get back to you";
                } 
            } else {
                echo ("Please verify you are human!");
                exit();
            }    
} else {
    die("<h2>Unauthorised access denied!</h2>");
    exit();
}
?>