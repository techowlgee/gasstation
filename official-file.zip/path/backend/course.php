<?php
    if(!isset($_POST['total-price'])) {
        echo "Cannot complete now..!";
        exit();
    } else {
        function test_post($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }
        $fullname = $_POST["fullname"];
        $email = $_POST["email"];
        $password = $_POST["password"];
        $course = $_POST["courses-chosen"];
        $price = $_POST["total-price"];
        $coupon = $_POST['coupon-hidden-input'];

        if(empty($fullname)) {
            echo "Empty name..";
            exit();
        }  else if(!preg_match("/^[a-zA-Z- ']*$/", $fullname)) {
            echo "wrong -6";
            exit();
        }  else {
            $fullname = test_post($fullname);           
        };
        if(empty($email)) {
            echo "Emtpy email..";
            exit();
                // Check if email address is well formed;
        } else if(!preg_match("/^[a-zA-Z0-9._]+@[a-zA-Z0-9-]+(.[a-zA-Z-]+)*$/", $email)) {
            echo "Invalid email";
            exit();
        } else if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
            echo "wrong -3";
            exit();
        } else {
               $email = test_post($email);
        };
        if(empty($password)) {
            echo "Empty password";
            exit();
            // Check if password is well formed
        }   else if(!preg_match("/^[a-zA-Z0-9_]*$/", $password)) {
            echo "Invalid password";
            exit();
        }   else {
                $password = test_post($password);
                $harshPassword = password_hash($password, PASSWORD_DEFAULT);
        
                $course = test_post($_POST["courses-chosen"]);
                $price = test_post($_POST["total-price"]);
                $coupon = test_post($_POST['coupon-hidden-input']);

                require "../../components/db_connect.php";
                $sql = "CREATE DATABASE IF NOT EXISTS official";
                if(mysqli_query($con, $sql)) {
                    $db_name = "official";
                    $connection = mysqli_connect($db_server, $db_user, $db_pass, $db_name);
                        if(!$connection) {
                            echo "Connection one failed";
                            exit();
                        } else {
                            $sql = "CREATE TABLE IF NOT EXISTS courserecord (
                                id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
                                fullname VARCHAR(60) NOT NULL,
                                email VARCHAR(60) NOT NULL,
                                password VARCHAR(255) NOT NULL,
                                courses VARCHAR(255) NOT NULL,
                                price DECIMAL(8,2) NOT NULL,
                                coupon VARCHAR(12) NOT NULL,
                                registertime TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
                                ) ENGINE = InnoDB DEFAULT CHARSET = latin1;";
                            if(!mysqli_query($connection, $sql)) {
                                echo "Query one failed";
                                exit();
                            } else {
                                $table = "courserecord";
                                $sql = "SELECT * FROM $table WHERE email = '$email' ";
                                if(!mysqli_query($connection, $sql)) { //If i can not run the query means the table is empty
                                    echo "Query two failed";
                                    exit();
                                } else {
                                    $result = mysqli_query($connection, $sql);
                                    if(mysqli_num_rows($result) > 0) {
                                        echo "account already exist";
                                        exit();
                                    } else {
                                        $sql = "INSERT INTO $table (fullname, email, password, courses, price, coupon)
                                        VALUES(?,?,?,?,?,?)";
                                        $stmt = mysqli_stmt_init($connection);
                                        if(!mysqli_stmt_prepare($stmt, $sql)) {
                                            echo "Query three failed";
                                            exit();
                                        } else {
                                            mysqli_stmt_bind_param($stmt, "ssssss", $fullname, $email, $harshPassword, $course, $price, $coupon);
                                            mysqli_stmt_execute($stmt);
                                            mysqli_stmt_store_result($stmt);

                                            session_start();
                                            $sql = "SELECT * FROM $table WHERE email = '$email' ";
                                            $result = mysqli_query($connection, $sql);
                                            if(mysqli_num_rows($result) > 0) {
                                                // OUTPUT
                                                while($row = mysqli_fetch_assoc($result)) {
                                                    $_SESSION["fullname"] = $row["fullname"];
                                                    $_SESSION["email"] = $row["email"];
                                                    $_SESSION["course"] = $row["courses"];
                                                    $_SESSION["price"] = $row["price"];
                                                    $_SESSION["coupon"] = $row["coupon"];
                                                    $_SESSION["booktime"] = $row["registertime"];
                                                    $_SESSION["IS_LOGIN"] = "Dfdjau49GHaE4N5dlgw";

                                                    mysqli_close($connection);
                                                    echo "Register success";
                                                    exit();
                                                };
                                            } else {
                                                echo "Could not register";
                                                exit();
                                            };
                                        }
                                    }
                                };
                                // 
                            };
                        }; 
                } else {
                    header("Location: ../../index.html");
                    exit();
                }
        };
    }
?>