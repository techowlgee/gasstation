<?php
    session_start();
    if(!isset($_SESSION['IS_LOGIN']) || $_SESSION['IS_LOGIN'] != "Dfdjau49GHaE4N5dlgw") {
        header("Location: ../../index.html");
        exit();
    } else {
        $fullname = $_SESSION["fullname"];
        $email = $_SESSION["email"];
        $course = $_SESSION["course"];
        $price = $_SESSION["price"];
        $coupon = $_SESSION["coupon"];
        $booktime = $_SESSION["booktime"];

        // echo $fullname . "<br/>" .  $email. "<br/>" . $course . "<br/>" .  $price . "<br/>" .  $coupon . "<br/>" .  $booktime . "<br/>";
    
    $_SESSION['IS_LOGOUT'] = "DfdBau49GHaE4N5dlgw";
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Dashboard</title>
    <link rel="apple-touch-icon" sizes="180x180" href="../../apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="../../favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="../../favicon-16x16.png">
    <link rel="manifest" href="../../site.webmanifest">

    <link rel="stylesheet" href="../../css/dashboard.css">
    <link rel="stylesheet" href="../../css/general-container.css">
    <link rel="stylesheet" href="../../css/fontawesome/free/css/fontawesome.css">
    <link rel="stylesheet" href="../../css/fontawesome/free/css/brands.css">
    <link rel="stylesheet" href="../../css/fontawesome/free/css/regular.css">
    <link rel="stylesheet" href="../../css/fontawesome/free/css/solid.css">
</head>
<body>
    <div class="general-container">
        <noscript>You need to activate javascript to utilize the use of this application</noscript>
        <div class="display-login-flex">
            <aside></aside>
            <div class="details">
                <h1 class="dashboard-heading general-heading oswald">WELCOME TO YOUR DASHBOARD</h1>
                <p class="dashboard-greeting mtop40">Dear <?php echo $fullname; ?></p>
                <p  class="text-font-size mtop20">Below is a complete summary of your registration</p>
                <table class="dashboard-table mtop40">
                    <tr>
                        <th>Email</th>
                        <td> <?php echo $email; ?></td>
                    </tr>
                    <tr>
                        <th>Course</th>
                        <td> <?php echo $course; ?></td>
                    </tr>
                    <tr>
                        <th>Price</th>
                        <td> <?php echo $price; ?>K</td>
                    </tr>
                    <tr>
                        <th>Coupon ID</th>
                        <td> <?php echo $coupon; ?></td>
                    </tr>
                    <tr>
                        <th>Booking Date</th>
                        <td><?php echo $booktime; ?></td>
                    </tr>
                </table>

                <div class="mtop40"><a class="logout-anchor" href="logout.php">Logout</a></div>
            </div>
        </div>
    </div>
</body>
</html>