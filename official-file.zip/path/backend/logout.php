<?php
    session_start();

    if(!isset($_SESSION['IS_LOGOUT']) || $_SESSION['IS_LOGOUT'] != "DfdBau49GHaE4N5dlgw") {
        // session_destroy();
        header("Location: ../../index.php");
        exit();
    } else {
        session_destroy();
        header("Location: ../login/login.php");
        exit();
    };
?>