<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Contact</title>
    <link rel="apple-touch-icon" sizes="180x180" href="../apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="../favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="../favicon-16x16.png">
    <link rel="manifest" href="../site.webmanifest">
    <meta name="title" content="Short story about the CEO of Techowlgee School of programming  in Nigeria &amp;: The Best Platform to Learn How To Code In Nigeria &amp;: Dev Roles | Gigs | Training | Tutorials | Mentoring">
    <meta name="robots" content="about page, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">
    <meta name="description" content="&quot; The Biggest Software Engineering and Web Developement Center in Lagos State Nigeria | We have a mission to train One Million Nigeria Youths Per YEar In Various Programming Courses. Join Us today to enhance your skill and unlock your financial freedom..">
    <meta property="og:locale" content="en_US">
    <meta property="og:type" content="website">
    <meta property="og:title" content="Software Engineering | Web Development | Database Management | Cyber Security | Tech Contractors, web developments | ">
    <meta property="og:url" content="https://techowlgee.com/path/about.html">
    <meta property="og:site_name" content="https://techowlgee.com">
    <meta property="article:publisher" content="https://web.facebook.com/techowlgee">
    <meta property="article:modified_time" content="2023-12-31T21:45:34+00:00">
    <meta property="og:image" content="https://techowlgee.com/images/ceo/ceo.webp">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:site" content="@techowlgee">
    <link rel="stylesheet" href="../css/contact.css">
    <link rel="stylesheet" href="../css/general-container.css">
    <link rel="stylesheet" href="../css/fontawesome/free/css/fontawesome.css">
    <link rel="stylesheet" href="../css/fontawesome/free/css/brands.css">
    <link rel="stylesheet" href="../css/fontawesome/free/css/regular.css">
    <link rel="stylesheet" href="../css/fontawesome/free/css/solid.css">
    <script src="../javascript/contact.js" defer></script>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
</head>

<body>
    <div class="general-container">
        <noscript>You need to activate javascript to utilize the use of this application</noscript>
        <header class="header" id="header" itemscope="itemscope" itemtype="https://schema.org/header">
            <div class="header-inner box-container">
                <div class="logo-element flex-row-center-left" title="Techowlgee Website Development Services in Lagos Nigeria">
                    <div class="techname-t">t <i class="fa fa-bug" arial-hidden="true"></i></div>
                    <div class="techname-gee">GEE</div>
                </div>
                <div class="menu-container">
                    <input type="checkbox" name="hamb-checkbox" id="hamb-checkbox" class="hamb-checkbox">
                    <nav>
                        <div class="menu-list-box">
                            <div class="list-item home-link"><a href="../index.html">Home</a></div>
                            <div class="list-item home-link"><a href="services.html">Services</a></div>
                            <div class="list-item home-link"><a href="tutorials.php">Tutorials</a></div>
                            <div class="list-item home-link"><a href="blog.html">Blog</a></div>
                            <div class="list-item home-link"><a href="about.html">About Us</a></div>
                            <div class="list-item-reg">
                                <div class="registration-box">
                                    <a href="register/register.php" id="register-anchor">Register</a>
                                    <a href="login/login.php" id="login-anchor">Login</a>
                                </div>
                            </div>
                        </div>
                    </nav>
                    <label for="hamb-checkbox" class="hamb"><span class="hamb-line"></span></label>
                </div>
            </div>
        </header>
            <main>
                <section class="contact-heading"> 
                    <h1 class="about-title general-heading center-text contact-title">Hire Us</h1>
                </section>
                <section class="section-contact mtop40">
                    <div class="flex-contact">
                        <div class="phone-email-contact">
                            <h4>We're here to support you</h4>
                            <p>Let's know about how you would want us to serve you better.</p>
                            <!-- ADDRESS -->
                            <div class="email-phone">
                                <div class="contact-icon email-phone-call-column-gap">
                                    <i class="fa fa-home" aria-hidden="true"></i>
                                </div>
                                <div class="email-phone-call">
                                    <h6>Visit us call at</h6>
                                    <span>1, Sule Abore Street, Ojodu, Lagos.</span>
                                </div>
                            </div>
                            <!-- PHONE -->
                            <div class="email-phone">
                                <div class="contact-icon email-phone-call-column-gap">
                                    <i class="fas fa-phone"></i>
                                </div>
                                <div class="email-phone-call">
                                    <h6>Give us a call on</h6>
                                    <span>+2349075620762</span>
                                </div>
                            </div>
                            <!-- EMAIL -->
                            <div class="email-phone">
                                <div class="contact-icon email-phone-call-column-gap">
                                    <i class="fa fa-envelope" aria-hidden="true"></i>
                                </div>
                                <div class="email-phone-call">
                                    <h6>Mail us at</h6>
                                    <a href="mailto: techowlgee@gmail.com" target="_self">techowlgee@gmail.com</a>
                                </div>
                            </div>
                        </div>
                        <div class="form-housing">                     
                                <h5>Send us a message</h5>
                                <form action="" id="contact-form" class="contact-form" enctype="multipart/form-data">
                                    <input type="text" id="fullname" name="fullname" placeholder="Full name*">
                                    <input type="email" id="email" name="email" placeholder="Email address*" autocomplete="false">
                                    <input type="text" id="subject" name="subject" placeholder="Subject">
                                    <div class="form-h6">
                                        <h6>Tell us about your peculiar need*</h6>
                                    </div>
                                    <textarea name="message" id="" cols="30" maxlength="140" rows="10" placeholder="Message/140 characters..."></textarea>
                                    <div class="g-recaptcha" data-sitekey="6LdcaKYnAAAAALI_hfylJcOVcnUozha23Zb3rKUR"></div>
                                    <button type="button" id="message-button" class="message-button" onclick="contactMessage();">Send message</button>
                                </form>
                        </div>
                    </div>
                </section>
                <section class="locate-us-on-map">
                    <h5>Locate us on the map</h5>
                    <div class="map">
                        <iframe title="google map" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3963.0535822307043!2d3.362385274064107!3d6.640268621797306!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x103b9391936d2d0b%3A0x5e3da30a977d7853!2s1%20Sule%20Abore%20Street%2C%20Ojodu%20101233%2C%20Ikeja%2C%20Lagos!5e0!3m2!1sen!2sng!4v1685465202454!5m2!1sen!2sng" width="100%" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                </section>
            </main>
            <footer>
            <div class="footer-container">
                <div class="footer-grid-child">
                    <h2>Services</h2>
                    <ul>
                        <li><a href="services.html#webdevelopment"><i class="fas fa-angle-double-right"></i>&nbsp;Web Developement</a></li>
                        <li><a href="services.html#softwareengineering"><i class="fas fa-angle-double-right"></i>&nbsp;Software Engineering</a></li>
                        <li><a href="services.html#dataanalysis"><i class="fas fa-angle-double-right"></i>&nbsp;Data Analysis</a></li>
                        <li><a href="services.html#webdevelopment"><i class="fas fa-angle-double-right"></i>&nbsp;Cyber Security</a></li>
                    </ul>
                </div>
                <div class="footer-grid-child">
                    <h2>Frontend</h2>
                    <ul>
                        <li><a href="tutorials.php#html"><i class="fas fa-angle-double-right"></i>&nbsp;HTML</a></li>
                        <li><a href="tutorials.php#css"><i class="fas fa-angle-double-right"></i>&nbsp;CSS</a></li>
                        <li><a href="tutorials.php#javascript"><i class="fas fa-angle-double-right"></i>&nbsp;JAVASCRIPT</a></li>
                        <li><a href="tutorials.php#html"><i class="fas fa-angle-double-right"></i>&nbsp;MYSQL</a></li>
                    </ul>
                </div>
                <div class="footer-grid-child">
                    <h2>Backend</h2>
                    <ul>
                        <li><a href="tutorials.php#php"><i class="fas fa-angle-double-right"></i>&nbsp;PHP</a></li>
                        <li><a href="tutorials.php#python"><i class="fas fa-angle-double-right"></i>&nbsp;PYTHON</a></li>
                        <li><a href="tutorials.php#mysql"><i class="fas fa-angle-double-right"></i>&nbsp;MYSQL</a></li>
                        <li><a href="tutorials.php#cpanel"><i class="fas fa-angle-double-right"></i>&nbsp;CPANEL</a></li>
                    </ul>
                </div>
                <div class="footer-grid-child">
                    <h2>Frameworks</h2>
                    <ul>
                        <li><a href="tutorials.php#hreact"><i class="fas fa-angle-double-right"></i>&nbsp;REACT</a></li>
                        <li><a href="tutorials.php#vue"><i class="fas fa-angle-double-right"></i>&nbsp;VUE</a></li>
                        <li><a href="tutorials.php#jquery"><i class="fas fa-angle-double-right"></i>&nbsp;JQUERY</a></li>
                        <li><a href="tutorials.php#django"><i class="fas fa-angle-double-right"></i>&nbsp;DJANGO</a></li>
                        <li><a href="tutorials.php#laravel"><i class="fas fa-angle-double-right"></i>&nbsp;LARAVEL</a></li>
                    </ul>
                </div>
            </div>
        

            <div class="social-media-grid mtop60">
                <div class="logo-element footer-logo flex-row-center-left" title="Techowlgee Website Development Services in Lagos Nigeria">
                    <div class="techname-t">t <i class="fa fa-bug" arial-hidden="true"></i></div>
                    <div class="techname-gee">GEE</div>
                </div>
                <div class="social-media mtop60 flex-row-center-right">
                    <a class="link-icons left-a" href="https://www.twitter.com/techowlgee" aria-label="twitter page link"><i class="fa-brands fa-twitter"></i></a>
                    <a class="link-icons left-a" href="https://www.instagram.com/techowlgee" aria-label="instagram page link"><i class="fa-brands fa-instagram"></i></a>
                    <a class="link-icons left-a" href="https://www.linkedin.com/in/techowlgee" aria-label="linkedin page link"><i class="fa-brands fa-linkedin"></i></a>
                    <a class="link-icons left" href="https://www.youtube.com/techowlgee" aria-label="youtube page link"><i class="fa-brands fa-youtube"></i></a>
                </div>
            </div>
            <div class="footer-copyright mtop40 flex-row-center-left">
                <p class="copyright">&#169; &nbsp;<span id="copyright_date"></span> Techowlgee</p>&nbsp;&nbsp;&nbsp;&nbsp;
                <p><i class="fa fa-lock" aria-hidden="true"></i>&nbsp;Secured with SSL</p>
            </div>
        </footer>
    </div>
</body>
</html>
            