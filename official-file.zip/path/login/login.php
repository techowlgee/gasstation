<?php
    // CHECK FOR REMEBER ME COOKIE
    if(isset($_COOKIE['username']) && isset($_COOKIE['userphone']) && isset($_COOKIE['userpass'])) {
        $useremail_cookie = $_COOKIE['username'];
        $userphone_cookie = $_COOKIE['userphone'];
        $userpassword_cookie = $_COOKIE['userpass'];
        $set_remember = "checked='checked'";
    } else {
        $useremail_cookie = '';
        $userphone_cookie = '';
        $userpassword_cookie = '';
        $set_remember = '';
    };
    $red = "style='border-color: red'";
    if(isset($_GET['error']) && $_GET['error'] == 'emptyemail') {
        $error_msg = "*Empty email field";
        $set = "one";
    }  else if(isset($_GET['error']) && $_GET['error'] == 'invalidemail') {
        $error_msg = "*Invalid email";
        $set = "one";
    } else if(isset($_GET['error']) && $_GET['error'] == 'pleaseverify') {
        $error_msg = "*Verify you are human";
        $set = "one";
    } else if(isset($_GET['error']) && $_GET['error'] == 'notexist') {
        $error_msg = "*Account non-existent!";
        $set = "one";
    } else if(isset($_GET['error']) && $_GET['error'] == 'unexpected') {
        $error_msg = "*Error: use matching login details!";
        $set = "one";
    } else if(isset($_GET['error']) && $_GET['error'] == 'invalidpass') {
        $error_msg = "* Invalid password";
        $set = "three";
    } else if(isset($_GET['error']) && $_GET['error'] == 'wrongpass') {
        $error_msg = "* Wrong password";
        $set = "three";
    } else {
        $error_msg = "";
        $set = "";
    };

    //SERVER REQUEST PROCESSING FOR FORM
    if($_SERVER["REQUEST_METHOD"] == "POST") {

        function validate_input($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        };

            //Verify recaptcha
            $recaptcha = $_POST['g-recaptcha-response'];
            $secret_key = '6LdcaKYnAAAAABOWqZSKVsJc6HI6RWLTswUP_N55';
            $url = 'https://www.google.com/recaptcha/api/siteverify?secret=' . $secret_key . '&response='. $recaptcha . '&remoteip=' . $_SERVER['REMOTE_ADDR'];
            $response = file_get_contents($url);
            $response = json_decode($response);
        
            if($response->success == true) {
                $email = $_POST["email"];
                $password = $_POST["password"];

                if(empty($email)) {
                    header("Location: login.php?error=emptyemail");
                    exit();
                } else if(!preg_match("/^[a-zA-Z0-9._]+@[a-zA-Z0-9-]+(.[a-zA-Z-]+)*$/", $email)) {
                    header("Location: login.php?error=invalidemail");
                    exit();
                } else if(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    header("Location: login.php?error=invalidemail");
                    exit();
                } else {
                    $email = validate_input($email);
                };
                if(empty($password)) {
                    header("Location: login.php?error=emptypass");
                    exit();
                } else if(!preg_match("/^[a-zA-Z0-9_]*$/", $password)) {
                    header("Location: login.php?error=invalidpass");
                    exit();
                } else {
                    $password = validate_input($password);
                };
                // CHECK IF REMEBER ME IS CHECKED
                if(isset($_POST['remember'])) {
                    setcookie('username', $email, time() + 86400000);
                    setcookie('userphone', $phone, time() + 86400000);
                    setcookie('userpass', $password, time() + 86400000);
                } else {
                    setcookie('username', $email, time() - 86400000);
                    setcookie('userpass', $password, time() - 86400000);
                }

                require("../../components/db_connect.php");
                if(!$con) {
                    header("Location: login.php?error=unexpected");
                    exit();
                } else {
                    $db_name = "official";
                    $connection = mysqli_connect($db_server, $db_user, $db_pass, $db_name);
                    if(!$connection) {
                        header("Location: login.php?error=unexpected");
                        exit();
                    } else {
                        $table = "courserecord";

                        // $sql = "SELECT * FROM $table WHERE email = ?";
                        // $stmt = mysqli_stmt_init($connection);
                        // if(!mysqli_stmt_prepare($stmt, $sql)) {
                        //     header("Location: login.php?error=unexpected");
                        //     exit();
                        // } else {
                        //     mysqli_stmt_bind_param($stmt, "s", $email);
                        //     mysqli_stmt_execute($stmt);                 
                        //     $result = mysqli_stmt_get_result($stmt); //TO SELECT DATA use  mysqli_stmt_get_result($stmt) But to INSERT DATA use mysqli_stmt_store_result($stmt)
                        //     if(mysqli_stmt_num_rows($result) > 0) { 
                        //         if($row = mysqli_fetch_assoc($result)) {
                        //             $passCheck = password_verify($password, $row["password"]);
                        //             if($passCheck == false) {
                        //                 header("Location: login.php?error=wrongpass");
                        //                 exit();
                        //             } else if($passCheck == true) {
                        //                 session_start();
                        //                 $_SESSION["fullname"] = $row["fullname"];
                        //                 $_SESSION["email"] = $row["email"];
                        //                 $_SESSION["course"] = $row["courses"];
                        //                 $_SESSION["price"] = $row["price"];
                        //                 $_SESSION["coupon"] = $row["coupon"];
                        //                 $_SESSION["booktime"] = $row["registertime"];
                        //                 $_SESSION["IS_LOGIN"] = "Dfdjau49GHaE4N5dlgw";
                        //             }
                        //         }
                        //             mysqli_close($connection);
                        //             mysqli_close($con);
                        //             header("Location: ../backend/dashboard.php");
                        //             exit();
                        //     } else {
                        //         header("Location: login.php?error=notexist");
                        //         exit();
                        //     }
        
                        // };
                        // ---------------------------------------------------------------------
                        $sql = "SELECT * FROM $table WHERE email = '$email'";
                        if(mysqli_query($connection, $sql)) {
                            $result = mysqli_query($connection, $sql);
                            if(mysqli_num_rows($result) > 0) {
                                if($row = mysqli_fetch_assoc($result)) { //added
                                    $passCheck = password_verify($password, $row["password"]);
                                    if($passCheck == false) {
                                        header("Location: login.php?error=wrongpass");
                                        exit();
                                    } else if($passCheck == true) {
                                        session_start();
                                        $_SESSION["fullname"] = $row["fullname"];
                                        $_SESSION["email"] = $row["email"];
                                        $_SESSION["course"] = $row["courses"];
                                        $_SESSION["price"] = $row["price"];
                                        $_SESSION["coupon"] = $row["coupon"];
                                        $_SESSION["booktime"] = $row["registertime"];
                                        $_SESSION["IS_LOGIN"] = "Dfdjau49GHaE4N5dlgw";
                                    }
                                }
                                    mysqli_close($connection);
                                    mysqli_close($con);
                                    header("Location: ../backend/dashboard.php");
                                    exit();
                            } else {
                                header("Location: login.php?error=notexist"); //added
                                exit();
                            }
                        } else {
                            header("Location: login.php?error=unexpected");
                            exit();
                        }
                    }
                }
            } else {
                header("Location: login.php?error=pleaseverify");
                exit();
            }
    }


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Login</title>
    <link rel="apple-touch-icon" sizes="180x180" href="../../apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="../../favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="../../favicon-16x16.png">
    <link rel="manifest" href="../../site.webmanifest">

    <link rel="stylesheet" href="../../css/login.css">
    <link rel="stylesheet" href="../../css/general-container.css">
    <link rel="stylesheet" href="../../css/fontawesome/free/css/fontawesome.css">
    <link rel="stylesheet" href="../../css/fontawesome/free/css/brands.css">
    <link rel="stylesheet" href="../../css/fontawesome/free/css/regular.css">
    <link rel="stylesheet" href="../../css/fontawesome/free/css/solid.css">
    <script src="../../javascript/login.js" defer></script>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
</head>
<body class="background-image">
    <div class="general-container">
    <noscript>You need to activate javascript to utilize the use of this application</noscript>
        <div class="login-form-container">
            <h2 class="enroll-form-heading oswald center-text">LOGIN FORM</h2>
            <form  id="login-form" class="mtop20" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" onsubmit="return validateForm();" method="POST">
                <label for="email">Email: <span class="echo-error"><?php if(isset($set) && $set == "one") { echo $error_msg; } ?></span></label>
                <input id="email" type="text" class="input-error" name="email"  value="<?php echo $useremail_cookie; ?>"  <?php if(isset($set) && $set == "one") { echo $red; } ?>  placeholder="email..">
                <label for="password">Password: <span class="echo-error"><?php if(isset($set) && $set == "three") { echo $error_msg; } ?></span></label>
                <div class="show-password-div">
                    <input id="password" type="password" class="input-error" name="password" value="<?php echo $userpassword_cookie; ?>" <?php if(isset($set) && $set == "three") { echo $red; } ?> placeholder="password..">
                    <span id="show-pass" class="show-pass"><i class="fa-solid fa-eye"></i></span>
                    <span id="show-pass2" class="show-pass hide-display"><i class="fa-solid fa-eye-slash"></i></span>
                </div>
                <div class="g-recaptcha" data-sitekey="6LdcaKYnAAAAALI_hfylJcOVcnUozha23Zb3rKUR"></div>
                <input type="submit" id="login-button" class="submit-input" name="login" value="Login">
                <button type="button" class="spinner-button flex-row-center-center hide-display">
                    <div class="spin-div"></div>&nbsp; Please wait..
                </button>    
            </form>
            <div class="flex-row-center-space-between mtop20">
                <div class="checkbox-input-div">
                    <input type="checkbox" form="login-form" name="remember" id="remember" <?php echo $set_remember; ?>> &nbsp; <label for="remember" class="remember-label">Remember Me</label>
                </div>
                <a href="../../index.html" class="homepage-anchor" target="_self">Homepage</a>
            </div>
            <div class="account-holder mtop10">Don't have an account? <a href="../register/register.php">Register</a></div>
       </div>
    </div>
</body>
</html>