<?php
        $red = "style='border-color: red'";
        if(isset($_GET['error']) && $_GET['error'] == 'emptyfullname') {
                $err_msg = "&nbsp;*Enter fullname &nbsp;";
                $set = "food1";
        } else if(isset($_GET['error']) && $_GET['error'] == 'failed') {
            $err_msg = "&nbsp;*Registration failed. Please try again &nbsp;";
            $set = "food1";
        } else if(isset($_GET['error']) && $_GET['error'] == 'pleaseverify') {
            $err_msg = "&nbsp;*Verify you are human;";
            $set = "food1";
        } else if(isset($_GET['error']) && $_GET['error'] == 'invalidname') {
            $err_msg = "&nbsp;*Enter valid name &nbsp;";
            $set = "food1";
        } else if(isset($_GET['error']) && $_GET['error'] == 'emptyemail') {
            $err_msg = "&nbsp;*Enter email &nbsp;";
            $set = "food2";
        } else if(isset($_GET['error']) && $_GET['error'] == 'invalidemail') {
            $err_msg = "&nbsp;*Enter valid email &nbsp;";
            $set = "food2";
        } else if(isset($_GET['error']) && $_GET['error'] == 'emailtaken') {
            $err_msg = "&nbsp;*Email number taken &nbsp;";
            $set = "food2";
        } else if(isset($_GET['error']) && $_GET['error'] == 'emptypassword') {
            $err_msg = "&nbsp;*Enter password &nbsp;";
            $set = "food3";
        } else if(isset($_GET['error']) && $_GET['error'] == 'invalidpassword') {
            $err_msg = "&nbsp;*Alphanumeric & underscore allowed &nbsp;";
            $set = "food3";
        } else if(isset($_GET['error']) && $_GET['error'] == 'emptyservice') {
            $err_msg = "&nbsp;*Select service type &nbsp;";
            $set = "food4";
        } else if(isset($_GET['error']) && $_GET['error'] == 'nogender') {
            $err_msg = "&nbsp;*Select gender &nbsp;";
            $set = "food5";
        } else {
            $err_msg = "";
            $set = "";
        };
        $fullname = $_POST["fullname"]??'';
        $email = $_POST["email"]??'';
        $password = $_POST["password"]??'';
        $service = $_POST["service"]??'';
        $gender = $_POST["gender"]??'';

        if($_SERVER["REQUEST_METHOD"] == "POST") {
            function test_post($data) {
                $data = trim($data);
                $data = stripslashes($data);
                $data = htmlspecialchars($data);
                return $data;
            }

            $fullname = $_POST["fullname"];
            $email = $_POST["email"];
            $password = $_POST["password"];
            $service = $_POST["service"];
            $gender = $_POST["gender"];

            //Storing google recaptcha response in $recaptcha variable
            $recaptcha = $_POST['g-recaptcha-response'];
            $secret_key = '6LdcaKYnAAAAABOWqZSKVsJc6HI6RWLTswUP_N55';
            $url = 'https://www.google.com/recaptcha/api/siteverify?secret=' . $secret_key . '&response='. $recaptcha . '&remoteip=' . $_SERVER['REMOTE_ADDR'];
            $response = file_get_contents($url);
            $response = json_decode($response);

            if($response->success == true) {
                if(empty($fullname)) {
                    header("Location: register.php?error=emptyfullname");
                    exit();
                }  else if(!preg_match("/^[a-zA-Z- ']*$/", $fullname)) {
                    header("Location: register.php?error=invalidname");
                    exit();
                }  else {
                    $fullname = test_post($fullname);           
                };
                if(empty($email)) {
                    header("Location: register.php?error=emptyemail");
                    exit();
                        // Check if email address is well formed;
                } else if(!preg_match("/^[a-zA-Z0-9._]+@[a-zA-Z0-9-]+(.[a-zA-Z-]+)*$/", $email)) {
                    header("Location: register.php?error=invalidemail");
                    exit();
                } else if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
                        header("Location: register.php?error=invalidemail");
                        exit();
                } else {
                       $email = test_post($email);
                };
                if(empty($password)) {
                    header("Location: register.php?error=emptypassword");
                        exit();
                        //   Check if password is well formed
                }   else if(!preg_match("/^[a-zA-Z0-9_]*$/", $password)) {
                    header("Location: register.php?error=invalidpassword");
                        exit();
                }   else {
                      $password = test_post($password);
                      $harshPassword = password_hash($password, PASSWORD_DEFAULT);
                };
                if(empty($service)) {
                    header("Location: register.php?error=emptyservice");
                        exit();
                 } else {
                     $service = test_post($service);  
                    //  USE SERVICE CHOICE TO SET PRICE
                     if($service == "FROND END") {
                        $price = 250.00; 
                     } else if($service == "BACK END") {
                        $price = 450.00;
                     } else if($service == "CYBERSECURITY") {
                        $price = 350.00;
                     } else if($service == "MYSQ") {
                        $price = 150.00;
                     } else {
                        $price = 100.00;
                     };
                };
                if(empty($gender)) {
                    header("Location: register.php?error=nogender");
                       exit();  
                } else {
                    $gender = test_post($gender);
                };

                require "../../components/db_connect.php";
                $sql = "CREATE DATABASE IF NOT EXISTS official";
                if(mysqli_query($con, $sql)) {
                    $db_name = "official";
                    $connection = mysqli_connect($db_server, $db_user, $db_pass, $db_name);
                    if($connection) {
                        $sql = "CREATE TABLE IF NOT EXISTS courserecord (
                            id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
                            fullname VARCHAR(60) NOT NULL,
                            email VARCHAR(60) NOT NULL,
                            password VARCHAR(255) NOT NULL,
                            courses VARCHAR(255) NOT NULL,
                            price DECIMAL(8,2) NOT NULL,
                            coupon VARCHAR(12) NOT NULL,
                            registertime TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
                            ) ENGINE = InnoDB DEFAULT CHARSET = latin1;";

                                if(mysqli_query($connection, $sql)) {
                                    $sql = "SELECT * FROM courserecord WHERE email = ?";
                                    $stmt = mysqli_stmt_init($connection);
                                    if(!mysqli_stmt_prepare($stmt, $sql)) {
                                        header("Location: register.php?error=failed");
                                        exit();
                                    } else {
                                        mysqli_stmt_bind_param($stmt, "ss", $email, $phone);
                                        mysqli_stmt_execute($stmt);
                                        // mysqli_stmt_store_result($stmt);
                                        mysqli_stmt_get_result($stmt);
                                        $rowCount = mysqli_stmt_num_rows($stmt);
                                        if($rowCount > 0) {
                                            header("Location: register.php?error=emailtaken");
                                            exit();
                                        } else {
                                            $sql = "INSERT INTO courserecord(fullname, email, password, courses, price, coupon)
                                            VALUES(?, ?, ?, ?, ?, ?)";
                                            $stmt = mysqli_stmt_init($connection);
                                            if(!mysqli_stmt_prepare($stmt, $sql)) {
                                                header("Location: register.php?error=failed");
                                                exit();
                                            } else {
                                                mysqli_stmt_bind_param($stmt, "ssssss", $fullname, $email, $harshPassword, $service, $price, $gender);
                                                mysqli_stmt_execute($stmt);
                                                mysqli_stmt_store_result($stmt);

                                                session_start();
                                                $sql = "SELECT * FROM  courserecord WHERE email = '$email' ";
                                                $result = mysqli_query($connection, $sql);
                                                if(mysqli_num_rows($result) > 0) {
                                                    // OUTPUT
                                                    while($row = mysqli_fetch_assoc($result)) {
                                                        $_SESSION["fullname"] = $row["fullname"];
                                                        $_SESSION["email"] = $row["email"];
                                                        $_SESSION["course"] = $row["courses"];
                                                        $_SESSION["price"] = $row["price"];
                                                        $_SESSION["coupon"] = $row["coupon"];
                                                        $_SESSION["booktime"] = $row["registertime"];
                                                        $_SESSION["IS_LOGIN"] = "Dfdjau49GHaE4N5dlgw";
    
                                                        mysqli_close($connection);
                                                        header("Location: ../backend/dashboard.php");
                                                        exit();
                                                    };
                                                } else {
                                                    header("Location: register.php?error=failed");
                                                    exit();
                                                }
                                            }
                                        }
                                    }
                                } else {
                                    header("Location: register.php?error=failed");
                                    exit();
                                }
                    } else {
                        header("Location: register.php?error=failed");
                        exit();
                    }
                } else {
                    mysqli_close($con);
                    header("Location: register.php?error=failed");
                    exit();
                }

            } else {
                header("Location: register.php?error=pleaseverify");;
                exit();
            }
        }
?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Register</title>
    <link rel="apple-touch-icon" sizes="180x180" href="../../apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="../../favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="../../favicon-16x16.png">
    <link rel="manifest" href="../../site.webmanifest">
    <meta name="title" content="Techowlgee Programming Bootcamp in Nigeria &amp;: The Best Platform to Learn How To Code In Nigeria &amp;: Dev Roles | Gigs | Training | Tutorials | Mentoring">
    <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">
    <meta name="description" content="&quot; The Biggest Software Engineering and Web Developement Center in Lagos State Nigeria | We have a mission to train One Million Nigeria Youths Per YEar In Various Programming Courses. Join Us today to enhance your skill and unlock your financial freedom..">
    <meta property="og:locale" content="en_US">
    <meta property="og:type" content="website">
    <meta property="og:title" content="Software Engineering | Web Development | Database Management | Cyber Security | Tech Contractors, web developments | ">
    <meta property="og:url" content="https://techowlgee.com/path/register/register.php">
    <meta property="og:site_name" content="https://techowlgee.com">
    <meta property="article:publisher" content="https://web.facebook.com/techowlgee">
    <meta property="article:modified_time" content="2023-12-31T21:45:34+00:00">
    <meta property="og:image" content="https://techowlgee.com/images/newworld.jpg">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:site" content="@techowlgee">
    <link rel="stylesheet" href="../../css/register.css">
    <link rel="stylesheet" href="../../css/general-container.css">
    <link rel="stylesheet" href="../../css/fontawesome/free/css/fontawesome.css">
    <link rel="stylesheet" href="../../css/fontawesome/free/css/brands.css">
    <link rel="stylesheet" href="../../css/fontawesome/free/css/regular.css">
    <link rel="stylesheet" href="../../css/fontawesome/free/css/solid.css">
    <script src="../../javascript/register.js" defer></script>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
</head>

<body>
    <div class="general-container">
        <noscript>You need to activate javascript to utilize the use of this application</noscript>
        <div class="form-container">
            <div class="form-heading">
                <h1 class="general-heading">REGISTRATION FORM</h1>
            </div>
            <div class="form-housing mtop20">
                <form id="register-form" method="post" onsubmit="return validateForm();" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                    <label for="fullname">Fullname: <span class="echo"><?php if(isset($set) && $set == "food1") {echo $err_msg;}?></span></label>
                    <input type="text" name="fullname" id="fullname" class="input" <?php if(isset($set) && $set == "food1") {echo $red;}?> value="<?php echo $fullname; ?>" placeholder="Firstname.." >

                    <label for="email">Email: <span class="echo"><?php if(isset($set) && $set == "food2") {echo $err_msg;}?></span></label>
                    <input type="email" name="email" id="email" class="input" <?php if(isset($set) && $set == "food2") {echo $red;}?> value="<?php echo $email; ?>" placeholder="Your email..">

                    <label for="password">Password: <span class="echo"><?php if(isset($set) && $set == "food3") {echo $err_msg;}?></span></label>
                    <div class="show-pass-div">
                        <input type="password" name="password" id="password" class="input" <?php if(isset($set) && $set == "food3") {echo $red;}?>  value="<?php echo $password; ?>" maxlength="15" placeholder="Max characters 15..">
                        <span id="show-pass" class="show-pass"><i class="fa-solid fa-eye"></i></span>
                        <span id="show-pass2" class="show-pass hide-display"><i class="fa-solid fa-eye-slash"></i></span>
                    </div>
                    <label for="room">Service Type: <span class="echo"><?php if(isset($set) && $set == "food4") {echo $err_msg;}?></span></label>
                    <select form="register-form" id="room" class="input" <?php if(isset($set) && $set == "food5") {echo $red;}?> name="service">
                        <option value = "" disabled selected hidden>Choose Stack</option>
                        <option value="FROND END" <?php if(isset($service) && $service == "FROND END" ){ echo "selected";} ?>>FRONT END</option>
                        <option value="BACK END" <?php if(isset($service) && $service == "BACK END") {echo "selected";} ?>>BACK END</option>
                        <option value="CYBERSECURITY" <?php if(isset($service) && $service == "CYBERSECURITY") {echo "selected";} ?>>CYBERSECURITY</option>
                        <option value="MYSQL" <?php if(isset($service) && $service == "MYSQ") {echo "selected";} ?>>MYSQL</option>
                        <option value="DATA ANALYSIS" <?php if(isset($service) && $service == "DATA ANALYSIS") {echo "selected";} ?>>DATA ANALYSIS</option>
                    </select>
                    <div class="gender-span">Gender:<span class="echo"><?php if(isset($set) && $set == "food5") {echo $err_msg;}?></span>
                        &nbsp;&nbsp;  
                        <label class="gender-label" for="male">Male</label>&nbsp;&nbsp;                      
                        <input type="radio" id="male" name="gender" value="Male" <?php if(isset($gender) && $gender == "male") {echo "checked";} ?>> 
                        &nbsp;&nbsp; 
                        <label class="gender-label" for="female">Female</label>&nbsp;&nbsp;       
                        <input type="radio" id="female" name="gender" value="Female" <?php if(isset($gender) && $gender == "female") {echo "checked";} ?>>                 
                    </div>
                    <div class="g-recaptcha" data-sitekey="6LdcaKYnAAAAALI_hfylJcOVcnUozha23Zb3rKUR"></div>
                    <div class="submit-div">
                        <input type="submit" name="register" class="submit-input" value="Register"> 
                    </div> 
                    <button type="button" class="spinner-button flex-row-center-center hide-display">
                        <div class="spin-div"></div>&nbsp; Please wait..
                    </button>                  
                </form>

                <div class="login-div flex-row-center-space-between mtop10"> 
                    <h4>Already have an account?&nbsp;<a href="../login/login.php">Login</a></h4>
                    <a class="home-link" href="../../index.html">Homepage</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>