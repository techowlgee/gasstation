<?php
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trainings</title>
    <link rel="apple-touch-icon" sizes="180x180" href="../../apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="../../favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="../../favicon-16x16.png">
    <link rel="manifest" href="../../site.webmanifest">
    <link rel="stylesheet" href="../../css/trainings.css">
    <link rel="stylesheet" href="../../css/general-container.css">
    <link rel="stylesheet" href="../../css/fontawesome/free/css/fontawesome.css">
    <link rel="stylesheet" href="../../css/fontawesome/free/css/brands.css">
    <link rel="stylesheet" href="../../css/fontawesome/free/css/regular.css">
    <link rel="stylesheet" href="../../css/fontawesome/free/css/solid.css">
</head>
<body>
    <div class="general-container">
        <div class="training-login-box">
            <div class="training-form-box">
                <h2 class="general-heading oswald">Enter Your Course Login</h2>
                <div class="mtop60">
                    <form action="">
                        <label for="course-email" class="training-label">Email</label>
                        <input id="course-email" class="course-login" type="text" />
                        <label for="course-code" class="training-label">Access Code</label>
                        <input id="course-code" class="course-login" type="text" />
                        <input type="submit" value="Login" />
                    </form>
                </div>
                <a href="../tutorials.php" class="return-anchor">Retun to tutorial page</a>
            </div>
        <div>
    </div>
</body>
</html>