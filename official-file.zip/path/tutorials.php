<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Tutorials</title>
    <link rel="apple-touch-icon" sizes="180x180" href="../apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="../favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="../favicon-16x16.png">
    <link rel="manifest" href="../site.webmanifest">
    <meta name="title" content="Read about the services we offer in Lagos Nigeria &amp;: The Best Platform to Learn How To Code In Nigeria &amp;: Dev Roles | Gigs | Training | Tutorials | Mentoring">
    <meta name="robots" content="about page, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">
    <meta name="description" content="&quot; The Biggest Software Engineering and Web Developement Center in Lagos State Nigeria | We have a mission to train One Million Nigeria Youths Per YEar In Various Programming Courses. Join Us today to enhance your skill and unlock your financial freedom..">
    <meta property="og:locale" content="en_US">
    <meta property="og:type" content="website">
    <meta property="og:title" content="Software Engineering | Web Development | Database Management | Cyber Security | Tech Contractors, web developments | ">
    <meta property="og:url" content="https://techowlgee.com/path/tutorials.html">
    <meta property="og:site_name" content="https://techowlgee.com">
    <meta property="article:publisher" content="https://web.facebook.com/techowlgee">
    <meta property="article:modified_time" content="2023-12-31T21:45:34+00:00">
    <meta property="og:image" content="https://techowlgee.com/images/tier/tiertwo.webp">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:site" content="@techowlgee">
    <link rel="stylesheet" href="../css/tutorials.css">
    <link rel="stylesheet" href="../css/general-container.css">
    <link rel="stylesheet" href="../css/fontawesome/free/css/fontawesome.css">
    <link rel="stylesheet" href="../css/fontawesome/free/css/brands.css">
    <link rel="stylesheet" href="../css/fontawesome/free/css/regular.css">
    <link rel="stylesheet" href="../css/fontawesome/free/css/solid.css">
    <script src="../javascript/tutorials.js" defer></script>
</head>

<body>
    <div class="general-container">
        <noscript>You need to activate javascript to utilize the use of this application</noscript>
        <header class="header" id="header" itemscope="itemscope" itemtype="https://schema.org/header">
            <div class="header-inner box-container">
                <div class="logo-element flex-row-center-left" title="Techowlgee Website Development Services in Lagos Nigeria">
                    <div class="techname-t">t <i class="fa fa-bug" arial-hidden="true"></i></div>
                    <div class="techname-gee">GEE</div>
                </div>
                <div class="menu-container">
                    <input type="checkbox" name="hamb-checkbox" id="hamb-checkbox" class="hamb-checkbox">
                    <nav>
                        <div class="menu-list-box">
                            <div class="list-item home-link"><a href="../index.html">Home</a></div>
                            <div class="list-item home-link"><a href="services.html">Services</a></div>
                            <div class="list-item home-link"><a href="tutorials.php">Tutorials</a></div>
                            <div class="list-item home-link"><a href="blog.html">Blog</a></div>
                            <div class="list-item home-link"><a href="about.html">About Us</a></div>
                            <div class="list-item-reg">
                                <div class="registration-box">
                                    <a href="register/register.php" id="register-anchor">Register</a>
                                    <a href="login/login.php" id="login-anchor">Login</a>
                                </div>
                            </div>
                        </div>
                    </nav>
                    <label for="hamb-checkbox" class="hamb"><span class="hamb-line"></span></label>
                </div>
            </div>
        </header>

        <main>
        <section class="section-tutorials">
                <div class="each-services-box html">
                    <div class="each-services">
                        <div class="service-elements center-text">
                            <h2 class="language-title oswald center-text">HTML</h2>
                            <p class="language-text center-text mtop20">The markup language for building web pages</p>
                            <div class="anchor-div">
                                <a class="start-anchor start mtop20" href="tutorial/trainings.php?course=html&type=text">Start learning</a>
                                <a class="start-anchor video mtop20" href="tutorial/trainings.php?course=html&tyle=video">Video Tuorials</a>
                                <a class="start-anchor ref mtop20" href="tutorial/trainings.php?course=html&type=reference">References</a>
                            </div>
                        </div>
                        <div class="learning-example">
                            <div class="learning-example">
                                <h3 class="example-heading oswald">HTML EXAMPLE</h3>
                            </div>
                            <div class="template-sample">
                                <p><span class="sign-blue">&lt;</span><span class="sign-gold">!DOCTYPE</span> <span class="sign-red">html</span><span class="sign-blue">&gt;</span></p>
                                <p class="mtop5"><span class="sign-blue">&lt;</span>html<span class="sign-blue">&gt;</span></p>
                                <p class="mtop5"><span class="sign-blue">&lt;</span><span class="sign-gold">head</span><span class="sign-blue">&gt;</span></p>
                                <p class="mtop5"><span class="sign-blue">&lt;</span><span class="sign-gold">title</span><span class="sign-blue">&gt;</span>HTML Tutorials<span class="sign-blue">&lt;</span><span class="sign-gold">/title</span><span class="sign-blue">&gt;</span></p>
                                <p class="mtop5"><span class="sign-blue">&lt;</span><span class="sign-gold">/head</span><span class="sign-blue">&gt;</span></p>
                                <p class="mtop5"><span class="sign-blue">&lt;</span>body<span class="sign-blue">&gt;</span></p>
                                <p class="mtop30"><span class="sign-blue">&lt;</span>h1<span class="sign-blue">&gt;</span>This is a heading.<span class="sign-blue">&lt;</span>/h1<span class="sign-blue">&gt;</span></p>
                                <p class="mtop10"><span class="sign-blue">&lt;</span>p1<span class="sign-blue">&gt;</span>This is a paragraph.<span class="sign-blue">&lt;</span>/p1<span class="sign-blue">&gt;</span></p>
                                <p class="mtop30"><span class="sign-blue">&lt;</span>/body<span class="sign-blue">&gt;</span></p>
                                <p class="mtop5"><span class="sign-blue">&lt;</span>/html<span class="sign-blue">&gt;</span></p>
                            </div>
                            <div class="learn-more-housing mtop20">
                                <a class="learn-more mtop20" href="tutorial/trainings.php?course=html&type=learnmore">Learn More</a>
                            </div>                         
                        </div>
                    </div>
                </div>
                <div class="each-services-box css">
                    <div class="each-services">
                        <div class="service-elements center-text">
                            <h2 class="language-title oswald center-text">CSS</h2>
                            <p class="language-text center-text mtop20">The design language for styling web pages</p>
                            <div class="anchor-div">
                                <a class="start-anchor start mtop20" href="tutorial/trainings.php?course=css&type=text">Start learning</a>
                                <a class="start-anchor video mtop20" href="tutorial/trainings.php?course=css&type=video">Video Tuorials</a>
                                <a class="start-anchor ref mtop20" href="tutorial/trainings.php?course=css&type=reference">References</a>
                            </div>
                        </div>
                        <div class="learning-example">
                            <div class="learning-example">
                                <h3 class="example-heading oswald">CSS EXAMPLE</h3>
                            </div>
                            <div class="template-sample">
                                <p><span class="sign-gold">body</span> &#123;</p>
                                <p class="mtop10">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="sign-red">background-color</span>: <span class="sign-blue">rebecca-purple</span></p>
                                <p class="mtop5">&#123;</p>

                                <p class="mtop20"><span class="sign-gold">h1</span> &#123;</p>
                                <p class="mtop10">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="sign-red">font-size</span>: <span class="sign-blue">32px</span></p>
                                <p class="mtop5">&#10101;</p>

                                <p class="mtop20"><span class="sign-gold">p</span> &#123;</p>
                                <p class="mtop10">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="sign-red">font-family</span>: <span class="sign-blue">Helvetica</span></p>
                                <p class="mtop5">&#10101;</p>
                            </div>
                            <div class="learn-more-housing mtop20">
                                <a class="learn-more mtop20" href="tutorial/trainings.php?course=css&type=learnmore">Learn More</a>
                            </div>                         
                        </div>
                    </div>
                </div>
                <div class="each-services-box javascript">
                    <div class="each-services">
                        <div class="service-elements center-text">
                            <h2 class="language-title oswald center-text">JAVASCRIPT</h2>
                            <p class="language-text center-text mtop20">The design language for styling web pages</p>
                            <div class="anchor-div">
                                <a class="start-anchor start mtop20" href="tutorial/trainings.php?course=js&type=text">Start learning</a>
                                <a class="start-anchor video mtop20" href="tutorial/trainings.php?course=js&type=video">Video Tuorials</a>
                                <a class="start-anchor ref mtop20" href="tutorial/trainings.php?course=js&type=reference">References</a>
                            </div>
                        </div>
                        <div class="learning-example">
                            <div class="learning-example">
                                <h3 class="example-heading oswald">JAVASCRIPT EXAMPLE</h3>
                            </div>
                            <div class="template-sample">
                                <p class="mtop5"><span class="sign-blue">&lt;</span><span class="sign-gold">script</span><span class="sign-blue">&gt;</span></p>
                                <p class="mtop10"><span class="sign-blue">function</span> executeJavascript() &nbsp;&#123;</p>
                                <p class="mtop10">&nbsp;&nbsp;&nbsp;&nbsp;<span class="sign-blue">let</span> &nbsp;x &#61; &#91;"Bread", "Tea", "Sugar", "Cup", "Spoon"&#93;;</p>
                                <p class="mtop5">&nbsp;&nbsp;&nbsp;&nbsp;<span class="sign-blue">let</span> &nbsp;arrayLenght &#61; x.lenght</p>
                                <p class="mtop5">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="sign-gold">for</span> &nbsp;&#40;<span class="sign-blue"> let</span> i &#61; 0; i &lt; 0; i++ &#41; &nbsp;&#123;</p>
                                <p class="mtop5">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="sign-red">window.alert</span>&#40; x&#91; i &#93; &#41;</p>
                                <p class="mtop5">&nbsp;&nbsp;&nbsp;&nbsp;&#10101;</p>
                                <p class="mtop20">&#10101;</p>
                                <p class="mtop5"><span class="sign-blue">&lt;</span><span class="sign-gold">/script</span><span class="sign-blue">&gt;</span></p>
                            </div>
                            <div class="learn-more-housing mtop20">
                                <a class="learn-more mtop20" href="tutorial/trainings.php?course=js&type=learnmore">Learn More</a>
                            </div>                         
                        </div>
                    </div>
                </div>
                <div class="each-services-box php">
                    <div class="each-services">
                        <div class="service-elements center-text">
                            <h2 class="language-title oswald center-text">PHP</h2>
                            <p class="language-text center-text mtop20">Server scripting language of the web</p>
                            <div class="anchor-div">
                                <a class="start-anchor start mtop20" href="tutorial/trainings.php?course=php&type=text">Start learning</a>
                                <a class="start-anchor video mtop20" href="tutorial/trainings.php?course=php&type=video">Video Tuorials</a>
                                <a class="start-anchor ref mtop20" href="tutorial/trainings.php?course=php&type=reference">References</a>
                            </div>
                        </div>
                        <div class="learning-example">
                            <div class="learning-example">
                                <h3 class="example-heading oswald">PHP EXAMPLE</h3>
                            </div>
                            <div class="template-sample">
                                <p class="mtop5"><span class="sign-gold">&lt;</span><span class="sign-red">?</span><span class="sign-blue">php</span></p>
                                <p class="mtop10"> &nbsp; &nbsp; &nbsp; <span class="sign-gold">$</span><span class="sign-blue">Count</span> &nbsp; <span class="sign-red">&#61;</span> &nbsp; 20<span class="sign-gold">;</span></p>
                                <p class="mtop10"> &nbsp; &nbsp; &nbsp; <span class="sign-gold">$</span><span class="sign-blue">Output</span> &nbsp; <span class="sign-red">&#61;</span> &nbsp; ""<span class="sign-gold">;</span></p>
                                <p class="mtop10"> &nbsp; &nbsp; &nbsp; <span class="sign-blue">while</span><span class="sign-red">&#40;</span> <span class="sign-gold">$</span><span class="sign-blue">Count</span> &nbsp; <span class="sign-red">&lt;</span> &nbsp; <span class="sign-blue">25</span> <span class="sign-red">&#41;</span> &nbsp;  &nbsp;<span class="sign-gold">&#123;</span></p>
                                <p class="mtop10"> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <span class="sign-gold">$</span><span class="sign-blue">Count</span> &nbsp; <span class="sign-red">.</span><span class="sign-gold">&#61;</span>&nbsp; <span class="sign-blue">1</span><span class="sign-gold">;</span></p>
                                <p class="mtop10"> &nbsp; &nbsp; &nbsp; <span class="sign-gold">&#10101;</span>
                                <p class="mtop10"> &nbsp; &nbsp; &nbsp; <span class="sign-gold">$</span><span class="sign-blue">Output</span> &nbsp; <span class="sign-red">&#61;</span> &nbsp; <span class="sign-gold">$</span><span class="sign-blue">Count</span> <span class="sign-gold">;</span></p>
                                <p class="mtop10"> &nbsp; &nbsp; &nbsp; <span class="sign-red">echo</span> <span class="sign-gold">$</span><span class="sign-blue">Output</span><span class="sign-gold">;</span></p>
                                <p class="mtop10"><span class="sign-red">?</span><span class="sign-gold">&gt;</span></p>
                            </div>
                            <div class="learn-more-housing mtop20">
                                <a class="learn-more mtop20" href="tutorial/trainings.php?course=php&type=learnmore">Learn More</a>
                            </div>                         
                        </div>
                    </div>
                </div>
                <div class="each-services-box python">
                    <div class="each-services">
                        <div class="service-elements center-text">
                            <h2 class="language-title oswald center-text">PYTHON</h2>
                            <p class="language-text center-text mtop20">General purpose scripting language</p>
                            <div class="anchor-div">
                                <a class="start-anchor start mtop20" href="tutorial/trainings.php?course=python&type=text">Start learning</a>
                                <a class="start-anchor video mtop20" href="tutorial/trainings.php?course=python&type=video">Video Tuorials</a>
                                <a class="start-anchor ref mtop20" href="tutorial/trainings.php?course=python&type=reference">References</a>
                            </div>
                        </div>
                        <div class="learning-example">
                            <div class="learning-example">
                                <h3 class="example-heading oswald">PYTHON EXAMPLE</h3>
                            </div>
                            <div class="template-sample">
                                <p class="mtop5"> &nbsp; &nbsp; &nbsp; <span class="sign-blue">a</span> &nbsp; <span class="sign-red">&#61;</span> &nbsp; <span class="sign-blue"><span class="sign-gold">"</span>Python<span class="sign-gold">"</span></span></p>
                                <p class="mtop10"> &nbsp; &nbsp; &nbsp; <span class="sign-blue">b</span> &nbsp; <span class="sign-red">&#61;</span> &nbsp; <span class="sign-blue"><span class="sign-gold">"</span>is<span class="sign-gold">"</span></span></p>
                                <p class="mtop10"> &nbsp; &nbsp; &nbsp; <span class="sign-blue">c</span> &nbsp; <span class="sign-red">&#61;</span> &nbsp; <span class="sign-blue"><span class="sign-gold">"</span>a<span class="sign-gold">"</span></span></p>
                                <p class="mtop10"> &nbsp; &nbsp; &nbsp; <span class="sign-blue">d</span> &nbsp; <span class="sign-red">&#61;</span> &nbsp; <span class="sign-blue"><span class="sign-gold">"</span>powerful<span class="sign-gold">"</span></span></p>
                                <p class="mtop10"> &nbsp; &nbsp; &nbsp; <span class="sign-blue">e</span> &nbsp; <span class="sign-red">&#61;</span> &nbsp; <span class="sign-blue"><span class="sign-gold">"</span>programming<span class="sign-gold">"</span></span></p>
                                <p class="mtop10"> &nbsp; &nbsp; &nbsp; <span class="sign-blue">f</span> &nbsp; <span class="sign-red">&#61;</span> &nbsp; <span class="sign-blue"><span class="sign-gold">"</span>language<span class="sign-gold">"</span></span></p>
                                <p class="mtop20"> &nbsp; &nbsp; &nbsp; <span class="sign-gold">print</span><span class="sign-red">&#40;</span> &nbsp; <span class="sign-blue">a</span> &nbsp; <span class="sign-red">+</span>  &nbsp; <span class="sign-blue">b</span> &nbsp; <span class="sign-red">+</span>  &nbsp; <span class="sign-blue">c</span> &nbsp; <span class="sign-red">+</span>  &nbsp; <span class="sign-blue">d</span> &nbsp; <span class="sign-red">+</span>  &nbsp; <span class="sign-blue">e</span> &nbsp; <span class="sign-red">+</span>  &nbsp; <span class="sign-blue">f</span> &nbsp; <span class="sign-red">&#41;</span></p>
                            </div>
                            <div class="learn-more-housing mtop20">
                                <a class="learn-more mtop20" href="tutorial/trainings.php?course=php&type=learnmore">Learn More</a>
                            </div>                         
                        </div>
                    </div>
                </div>
            </section>
        </main>
        <footer>
            <div class="footer-container">
                <div class="footer-grid-child">
                    <h2>Services</h2>
                    <ul>
                        <li><a href="services.html#webdevelopment"><i class="fas fa-angle-double-right"></i>&nbsp;Web Developement</a></li>
                        <li><a href="services.html#softwareengineering"><i class="fas fa-angle-double-right"></i>&nbsp;Software Engineering</a></li>
                        <li><a href="services.html#dataanalysis"><i class="fas fa-angle-double-right"></i>&nbsp;Data Analysis</a></li>
                        <li><a href="services.html#webdevelopment"><i class="fas fa-angle-double-right"></i>&nbsp;Cyber Security</a></li>
                    </ul>
                </div>
                <div class="footer-grid-child">
                    <h2>Frontend</h2>
                    <ul>
                        <li><a href="tutorials.php#html"><i class="fas fa-angle-double-right"></i>&nbsp;HTML</a></li>
                        <li><a href="tutorials.php#css"><i class="fas fa-angle-double-right"></i>&nbsp;CSS</a></li>
                        <li><a href="tutorials.php#javascript"><i class="fas fa-angle-double-right"></i>&nbsp;JAVASCRIPT</a></li>
                        <li><a href="tutorials.php#html"><i class="fas fa-angle-double-right"></i>&nbsp;MYSQL</a></li>
                    </ul>
                </div>
                <div class="footer-grid-child">
                    <h2>Backend</h2>
                    <ul>
                        <li><a href="tutorials.php#php"><i class="fas fa-angle-double-right"></i>&nbsp;PHP</a></li>
                        <li><a href="tutorials.php#python"><i class="fas fa-angle-double-right"></i>&nbsp;PYTHON</a></li>
                        <li><a href="tutorials.php#mysql"><i class="fas fa-angle-double-right"></i>&nbsp;MYSQL</a></li>
                        <li><a href="tutorials.php#cpanel"><i class="fas fa-angle-double-right"></i>&nbsp;CPANEL</a></li>
                    </ul>
                </div>
                <div class="footer-grid-child">
                    <h2>Frameworks</h2>
                    <ul>
                        <li><a href="tutorials.php#hreact"><i class="fas fa-angle-double-right"></i>&nbsp;REACT</a></li>
                        <li><a href="tutorials.php#vue"><i class="fas fa-angle-double-right"></i>&nbsp;VUE</a></li>
                        <li><a href="tutorials.php#jquery"><i class="fas fa-angle-double-right"></i>&nbsp;JQUERY</a></li>
                        <li><a href="tutorials.php#django"><i class="fas fa-angle-double-right"></i>&nbsp;DJANGO</a></li>
                        <li><a href="tutorials.php#laravel"><i class="fas fa-angle-double-right"></i>&nbsp;LARAVEL</a></li>
                    </ul>
                </div>
            </div>
        

            <div class="social-media-grid mtop60">
                <div class="logo-element footer-logo flex-row-center-left" title="Techowlgee Website Development Services in Lagos Nigeria">
                    <div class="techname-t">t <i class="fa fa-bug" arial-hidden="true"></i></div>
                    <div class="techname-gee">GEE</div>
                </div>
                <div class="social-media mtop60 flex-row-center-right">
                    <a class="link-icons left-a" href="https://www.twitter.com/techowlgee" aria-label="twitter page link"><i class="fa-brands fa-twitter"></i></a>
                    <a class="link-icons left-a" href="https://www.instagram.com/techowlgee" aria-label="instagram page link"><i class="fa-brands fa-instagram"></i></a>
                    <a class="link-icons left-a" href="https://www.linkedin.com/in/techowlgee" aria-label="linkedin page link"><i class="fa-brands fa-linkedin"></i></a>
                    <a class="link-icons left" href="https://www.youtube.com/techowlgee" aria-label="youtube page link"><i class="fa-brands fa-youtube"></i></a>
                </div>
            </div>
            <div class="footer-copyright mtop40 flex-row-center-left">
                <p class="copyright">&#169; &nbsp;<span id="copyright_date"></span> Techowlgee</p>&nbsp;&nbsp;&nbsp;&nbsp;
                <p><i class="fa fa-lock" aria-hidden="true"></i>&nbsp;Secured with SSL</p>
            </div>
        </footer>
    </div>
</body>
</html>